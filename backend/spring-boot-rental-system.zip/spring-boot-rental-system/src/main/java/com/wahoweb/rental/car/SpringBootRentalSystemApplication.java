package com.wahoweb.rental.car;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootRentalSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRentalSystemApplication.class, args);
	}

}
